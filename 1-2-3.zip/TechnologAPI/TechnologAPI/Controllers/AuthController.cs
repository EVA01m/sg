﻿using Microsoft.AspNetCore.Mvc;
using TechnologAPI.Models;

namespace TechnologAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        // Имитация базы токенов (в реальности хранится в БД)
        public static List<string> ValidTokens = new List<string>();

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            // Простейшая проверка (в реальности - проверка хэша пароля из БД)
            if (request.Username == "technolog" && request.Password == "123")
            {
                string token = Guid.NewGuid().ToString(); // Генерируем токен
                ValidTokens.Add(token);
                return Ok(ApiResponse<string>.Ok(token, "Успешный вход"));
            }
            return Unauthorized(ApiResponse<string>.Error("Неверный логин или пароль"));
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}