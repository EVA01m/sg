﻿using Microsoft.AspNetCore.Mvc;
using TechnologAPI.Filters;
using TechnologAPI.Models;
using System.Data.SqlClient;

namespace TechnologAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [TokenAuth]
    public class ProductsController : ControllerBase
    {
        private readonly string _conn = @"Server=DESKTOP-6VOUGM6\SQLEXPRESS;Database=ProductionDB;Trusted_Connection=True;TrustServerCertificate=True;";

        [HttpGet]
        public IActionResult GetProducts()
        {
            var products = new List<Product>();
            try
            {
                using (SqlConnection conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    // Подтягиваем связанные рецептуры и техкарты (где статус 'approved')
                    string sql = @"
                        SELECT p.id, p.name, p.product_type_id, p.form_of_release, p.status,
                               (SELECT TOP 1 r.version FROM recipes r WHERE r.product_name = p.name AND r.status = 'approved') as ActiveRecipe,
                               (SELECT TOP 1 t.version FROM tech_maps t WHERE t.product_name = p.name AND t.status = 'approved') as ActiveTechMap
                        FROM products p
                        ORDER BY p.id";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    using (SqlDataReader r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            products.Add(new Product
                            {
                                Id = Convert.ToInt32(r["id"]),
                                Name = r["name"].ToString(),
                                Code = "PRD-" + r["id"].ToString(),
                                Type = r["product_type_id"].ToString(),
                                Form = r["form_of_release"].ToString(),
                                Status = r["status"].ToString(),
                                
                            });
                        }
                    }
                }
                return Ok(ApiResponse<List<Product>>.Ok(products));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponse<string>.Error(ex.Message));
            }
        }

        [HttpPost]
        public IActionResult CreateProduct([FromBody] Product newProduct)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_conn))
                {
                    conn.Open();
                    string sql = @"INSERT INTO products (name, product_type_id, form_of_release, status) 
                                   VALUES (@Name, @TypeId, @Form, 'active')";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@Name", newProduct.Name);

                    // Конвертируем строку в число (ID типа)
                    int typeId = 1;
                    int.TryParse(newProduct.Type, out typeId);
                    cmd.Parameters.AddWithValue("@TypeId", typeId);

                    cmd.Parameters.AddWithValue("@Form", newProduct.Form); // Форму пишем как текст

                    cmd.ExecuteNonQuery();
                }
                return Ok(ApiResponse<string>.Ok("", "Продукт успешно добавлен"));
            }
            catch (Exception ex)
            {
                return BadRequest(ApiResponse<string>.Error("Ошибка БД: " + ex.Message));
            }
        }

        [HttpPut("{id}/archive")]
        public IActionResult ArchiveProduct(int id)
        {
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                string sql = "UPDATE products SET status = 'archived' WHERE id = @Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
            return Ok(ApiResponse<string>.Ok("", "Продукт отправлен в архив"));
        }
    }
}