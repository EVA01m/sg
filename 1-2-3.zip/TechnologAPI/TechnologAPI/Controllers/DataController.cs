﻿using Microsoft.AspNetCore.Mvc;
using TechnologAPI.Filters;
using TechnologAPI.Models;
using System.Data.SqlClient;

namespace TechnologAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [TokenAuth]
    public class DataController : ControllerBase
    {
        private readonly string _conn = @"Server=DESKTOP-6VOUGM6\SQLEXPRESS;Database=ProductionDB;Trusted_Connection=True;";

        // --- GET МЕТОДЫ (Чтение) ---
        private List<T> GetList<T>(string tableName, Func<SqlDataReader, T> mapFunction)
        {
            var list = new List<T>();
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand($"SELECT * FROM {tableName}", conn);
                using (SqlDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read()) list.Add(mapFunction(r));
                }
            }
            return list;
        }

        [HttpGet("recipes")]
        public IActionResult GetRecipes() => Ok(ApiResponse<List<Recipe>>.Ok(GetList("recipes", r => new Recipe
        {
            Id = Convert.ToInt32(r["id"]),
            ProductName = r["product_name"].ToString(),
            Version = r["version"].ToString(),
            Status = r["status"].ToString(),
            Author = r["author"].ToString()
        })));

        [HttpGet("techmaps")]
        public IActionResult GetTechMaps() => Ok(ApiResponse<List<TechMap>>.Ok(GetList("tech_maps", r => new TechMap
        {
            Id = Convert.ToInt32(r["id"]),
            ProductName = r["product_name"].ToString(),
            Version = r["version"].ToString(),
            Status = r["status"].ToString()
        })));

        [HttpGet("orders")]
        public IActionResult GetOrders() => Ok(ApiResponse<List<ProductionOrder>>.Ok(GetList("production_orders", r => new ProductionOrder
        {
            Id = Convert.ToInt32(r["id"]),
            OrderNumber = r["order_number"].ToString(),
            ProductName = r["product_name"].ToString(),
            Date = Convert.ToDateTime(r["order_date"]),
            Status = r["status"].ToString()
        })));

        [HttpGet("batches")]
        public IActionResult GetBatches() => Ok(ApiResponse<List<ProductionBatch>>.Ok(GetList("production_batches", r => new ProductionBatch
        {
            Id = Convert.ToInt32(r["id"]),
            BatchNumber = r["batch_number"].ToString(),
            ProductName = r["product_name"].ToString(),
            Status = r["status"].ToString(),
            HasDeviations = Convert.ToBoolean(r["has_deviations"])
        })));

        [HttpGet("events")]
        public IActionResult GetEvents() => Ok(ApiResponse<List<EventItem>>.Ok(GetList("events", r => new EventItem
        {
            Id = Convert.ToInt32(r["id"]),
            Date = Convert.ToDateTime(r["event_date"]),
            Level = r["level"].ToString(),
            Description = r["description"].ToString()
        })));


        // --- POST МЕТОДЫ (Создание) ---

        [HttpPost("recipes")]
        public IActionResult CreateRecipe([FromBody] Recipe item)
        {
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                string sql = "INSERT INTO recipes (product_name, version, status, author) VALUES (@p1, @p2, 'draft', @p3)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@p1", item.ProductName ?? "Без названия");
                cmd.Parameters.AddWithValue("@p2", item.Version ?? "v.1.0");
                cmd.Parameters.AddWithValue("@p3", "Текущий технолог");
                cmd.ExecuteNonQuery();
            }
            return Ok(ApiResponse<string>.Ok("", "Рецептура создана"));
        }

        [HttpPost("techmaps")]
        public IActionResult CreateTechMap([FromBody] TechMap item)
        {
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                string sql = "INSERT INTO tech_maps (product_name, version, status) VALUES (@p1, @p2, 'draft')";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@p1", item.ProductName ?? "Без названия");
                cmd.Parameters.AddWithValue("@p2", item.Version ?? "v.1.0");
                cmd.ExecuteNonQuery();
            }
            return Ok(ApiResponse<string>.Ok("", "Техкарта создана"));
        }

        [HttpPost("orders")]
        public IActionResult CreateOrder([FromBody] ProductionOrder item)
        {
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                string sql = "INSERT INTO production_orders (order_number, product_name, order_date, status) VALUES (@p1, @p2, GETDATE(), 'Ожидает')";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@p1", item.OrderNumber ?? "ORD-NEW");
                cmd.Parameters.AddWithValue("@p2", item.ProductName ?? "Без названия");
                cmd.ExecuteNonQuery();
            }
            return Ok(ApiResponse<string>.Ok("", "Заказ создан"));
        }

        [HttpPost("batches")]
        public IActionResult CreateBatch([FromBody] ProductionBatch item)
        {
            using (SqlConnection conn = new SqlConnection(_conn))
            {
                conn.Open();
                string sql = "INSERT INTO production_batches (batch_number, product_name, status, has_deviations) VALUES (@p1, @p2, 'В производстве', 0)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@p1", item.BatchNumber ?? "BATCH-NEW");
                cmd.Parameters.AddWithValue("@p2", item.ProductName ?? "Без названия");
                cmd.ExecuteNonQuery();
            }
            return Ok(ApiResponse<string>.Ok("", "Партия создана"));
        }
    }
}