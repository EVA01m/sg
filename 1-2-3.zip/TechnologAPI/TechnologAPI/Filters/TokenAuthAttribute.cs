﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using TechnologAPI.Controllers;
using TechnologAPI.Models;

namespace TechnologAPI.Filters
{
    public class TokenAuthAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var authHeader = context.HttpContext.Request.Headers["Authorization"].ToString();

            // Убираем "Bearer " в любом регистре (Bearer, bearer, BEARER)
            var token = authHeader.Replace("Bearer ", "", System.StringComparison.OrdinalIgnoreCase).Trim();

            if (string.IsNullOrEmpty(token) || !AuthController.ValidTokens.Contains(token))
            {
                context.Result = new UnauthorizedObjectResult(ApiResponse<string>.Error("Токен недействителен или отсутствует"));
                return;
            }
            base.OnActionExecuting(context);
        }
    }
}