﻿namespace TechnologAPI.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string? Code { get; set; } // Добавили ?
        public string? Name { get; set; } // Добавили ?
        public string? Type { get; set; } // Добавили ?
        public string? Form { get; set; } // Добавили ?
        public string? Status { get; set; } // Добавили ?
    }
}