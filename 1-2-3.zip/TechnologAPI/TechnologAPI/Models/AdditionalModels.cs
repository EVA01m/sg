﻿namespace TechnologAPI.Models
{
    public class Recipe { public int Id { get; set; } public string ProductName { get; set; } public string Version { get; set; } public string Status { get; set; } public string Author { get; set; } }
    public class TechMap { public int Id { get; set; } public string ProductName { get; set; } public string Version { get; set; } public string Status { get; set; } }
    public class ProductionOrder { public int Id { get; set; } public string OrderNumber { get; set; } public string ProductName { get; set; } public DateTime Date { get; set; } public string Status { get; set; } }
    public class ProductionBatch { public int Id { get; set; } public string BatchNumber { get; set; } public string ProductName { get; set; } public string Status { get; set; } public bool HasDeviations { get; set; } }
    public class EventItem { public int Id { get; set; } public DateTime Date { get; set; } public string Level { get; set; } public string Description { get; set; } }
}