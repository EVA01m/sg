﻿USE ProductionDB;
GO


BEGIN TRY
    INSERT INTO recipes (product_id, version_no, status, is_active)
    VALUES (1, 3, N'approved', 1);
    PRINT N'ТЕСТ 1 ПРОВАЛЕН: вторая активная рецептура вставлена!';
END TRY
BEGIN CATCH
    PRINT N'ТЕСТ 1 ПРОЙДЕН: ' + ERROR_MESSAGE();
END CATCH;
GO


BEGIN TRY
    INSERT INTO recipes (product_id, version_no, status, is_active)
    VALUES (2, 2, N'draft', 0);
    DECLARE @new_recipe_id BIGINT = SCOPE_IDENTITY();

    INSERT INTO recipe_components (recipe_id, raw_material_id, share_percent)
    VALUES (@new_recipe_id, 1, 50.000),
           (@new_recipe_id, 2, 40.000); -- сумма 90%

    UPDATE recipes SET status = N'approved', is_active = 1
    WHERE id = @new_recipe_id;

    PRINT N'ТЕСТ 2 ПРОВАЛЕН: рецептура с суммой 90% утверждена!';
END TRY
BEGIN CATCH
    PRINT N'ТЕСТ 2 ПРОЙДЕН: ' + ERROR_MESSAGE();
END CATCH;
GO


BEGIN TRY
    INSERT INTO tech_cards (product_id, recipe_id, version_no, status, is_active)
    VALUES (1, 2, 3, N'approved', 1);
    PRINT N'ТЕСТ 3 ПРОВАЛЕН: вторая активная техкарта вставлена!';
END TRY
BEGIN CATCH
    PRINT N'ТЕСТ 3 ПРОЙДЕН: ' + ERROR_MESSAGE();
END CATCH;
GO


BEGIN TRY
    UPDATE recipe_components
    SET share_percent = 80
    WHERE recipe_id = 2 AND raw_material_id = 1;
    PRINT N'ТЕСТ 4 ПРОВАЛЕН: сумма долей утверждённой рецептуры стала 90%!';
END TRY
BEGIN CATCH
    PRINT N'ТЕСТ 4 ПРОЙДЕН: ' + ERROR_MESSAGE();
END CATCH;
GO

BEGIN TRY
    INSERT INTO recipes (product_id, version_no, status, is_active)
    VALUES (2, 5, N'draft', 0);
    DECLARE @ok_id BIGINT = SCOPE_IDENTITY();
    INSERT INTO recipe_components (recipe_id, raw_material_id, share_percent)
    VALUES (@ok_id, 1, 80.000), (@ok_id, 2, 20.000);
    UPDATE recipes SET status = N'approved', is_active = 0
    WHERE id = @ok_id;
    PRINT N'ПРОВЕРКА УСПЕШНОГО УТВЕРЖДЕНИЯ: пройдена (рецептура ' +
          CAST(@ok_id AS NVARCHAR(20)) + N' утверждена, но не активна)';
END TRY
BEGIN CATCH
    PRINT N'ПРОВЕРКА УСПЕШНОГО УТВЕРЖДЕНИЯ ПРОВАЛЕНА: ' + ERROR_MESSAGE();
END CATCH;
GO


PRINT N'--- Партии и их связка с рецептом/техкартой ---';
SELECT * FROM v_batch_full;

PRINT N'--- Прослеживаемость сырья ---';
SELECT * FROM v_raw_traceability;

PRINT N'--- Действующие утверждённые рецептуры ---';
SELECT * FROM v_active_recipes;

PRINT N'--- Журнал аудита (последние 20 событий) ---';
SELECT TOP 20 id, entity_type, entity_id, event_type,
              old_status, new_status, event_time
FROM audit_events
ORDER BY id DESC;
GO