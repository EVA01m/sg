﻿using System.Windows;
using System.Windows.Controls;

namespace DesktopTechnologWPF
{
    public partial class CreateProductWindow : Window
    {
        public CreateProductWindow() { InitializeComponent(); }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text) || CmbType.SelectedItem == null || CmbForm.SelectedItem == null)
            {
                MessageBox.Show("Заполните все поля!"); return;
            }

            // Берем ID типа из скрытого поля Tag
            string typeId = ((ComboBoxItem)CmbType.SelectedItem).Tag.ToString();
            string formName = ((ComboBoxItem)CmbForm.SelectedItem).Content.ToString();

            var newProduct = new Product
            {
                Name = TxtName.Text,
                Type = typeId,
                Form = formName
            };

            bool success = await ApiService.CreateProduct(newProduct);
            if (success)
            {
                MessageBox.Show("Продукт добавлен!");
                this.Close();
            }
            else MessageBox.Show("Ошибка при создании!");
        }
    }
}