﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class TechMapCardWindow : Window
    {
        public TechMapCardWindow(TechMap map)
        {
            InitializeComponent();
            TxtHeader.Text = $"Карта: {map.ProductName} (Версия: {map.Version})";
            TxtStatus.Text = $"Статус: {map.Status}";
            GridSteps.ItemsSource = map.Steps;
        }
    }
}