﻿using System.Windows;
using System.Windows.Controls;

namespace DesktopTechnologWPF
{
    public partial class TechMapsView : UserControl
    {
        public TechMapsView()
        {
            InitializeComponent();
            Loaded += TechMapsView_Loaded;
        }

        private async void TechMapsView_Loaded(object sender, RoutedEventArgs e)
        {
            GridMaps.ItemsSource = await ApiService.GetTechMaps();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            var win = new CreateTechMapWindow();
            win.ShowDialog();
            TechMapsView_Loaded(null, null); // Обновляем таблицу
        }
    }
}