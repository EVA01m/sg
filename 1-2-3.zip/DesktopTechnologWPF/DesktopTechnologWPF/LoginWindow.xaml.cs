﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private async void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Теперь TxtLogin и TxtPassword существуют, так как мы дали им имена в XAML
            bool success = await ApiService.Login(TxtLogin.Text, TxtPassword.Password);

            if (success)
            {
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль, либо сервер недоступен!", "Ошибка");
            }
        }
    }
}