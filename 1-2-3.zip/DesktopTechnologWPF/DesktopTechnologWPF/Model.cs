﻿using System;
using System.Collections.Generic;

namespace DesktopTechnologWPF
{
    public class Product
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Type { get; set; } // Здесь будет ID, но мы сделаем красиво в коде
        public string Form { get; set; }
        public string Status { get; set; }
        public string ActiveRecipe { get; set; } // НОВОЕ
        public string ActiveTechMap { get; set; } // НОВОЕ
    }

    // --- НОВЫЕ МОДЕЛИ ДЛЯ РАЗДЕЛОВ ---

    public class Recipe
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string Version { get; set; }
        public string Status { get; set; }
        public string Author { get; set; }
    }

    public class TechMap
    {
        public List<TechStep> Steps { get; set; } = new List<TechStep>();
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string Version { get; set; }
        public string Status { get; set; }
    }

    public class ProductionOrder
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; }
        public string ProductName { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }
    }

    public class ProductionBatch
    {
        public int Id { get; set; }
        public string BatchNumber { get; set; }
        public string ProductName { get; set; }
        public string Status { get; set; }
        public bool HasDeviations { get; set; }
    }

    public class EventItem
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Level { get; set; }
        public string Description { get; set; }
    }
    public class TechStep
    {
        public int Order { get; set; }
        public string Name { get; set; }
        public string Parameters { get; set; }
        public bool IsMandatory { get; set; }
    }
}