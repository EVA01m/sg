﻿using System.Windows;
using System.Windows.Controls;
namespace DesktopTechnologWPF
{
    public partial class ReportsView : UserControl
    {
        public ReportsView() { InitializeComponent(); }
        private async void BtnGenerate_Click(object sender, RoutedEventArgs e)
        {
            // Пример отчета по заказам
            var orders = await ApiService.GetOrders();
            GridReport.ItemsSource = orders;
            MessageBox.Show("Отчет сформирован по заказам!", "Успех");
        }
    }
}