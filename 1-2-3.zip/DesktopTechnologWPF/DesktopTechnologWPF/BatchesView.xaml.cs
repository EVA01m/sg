﻿using System.Windows;
using System.Windows.Controls;

namespace DesktopTechnologWPF
{
    public partial class BatchesView : UserControl
    {
        public BatchesView()
        {
            InitializeComponent();
            Loaded += BatchesView_Loaded;
        }

        private async void BatchesView_Loaded(object sender, RoutedEventArgs e)
        {
            GridBatches.ItemsSource = await ApiService.GetBatches();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            var win = new CreateBatchWindow();
            win.ShowDialog();
            BatchesView_Loaded(null, null); // Обновляем таблицу
        }
    }
}