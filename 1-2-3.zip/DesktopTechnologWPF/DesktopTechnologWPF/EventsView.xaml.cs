﻿using System.Windows.Controls;
namespace DesktopTechnologWPF
{
    public partial class EventsView : UserControl
    {
        public EventsView() { InitializeComponent(); Loaded += async (s, e) => { GridEventsAll.ItemsSource = await ApiService.GetEvents(); }; }
    }
}