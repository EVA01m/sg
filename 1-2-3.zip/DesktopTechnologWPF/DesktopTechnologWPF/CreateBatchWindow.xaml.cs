﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class CreateBatchWindow : Window
    {
        public CreateBatchWindow() { InitializeComponent(); }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var newItem = new ProductionBatch { BatchNumber = TxtBatchNumber.Text, ProductName = TxtProductName.Text };
            bool success = await ApiService.CreateBatch(newItem);
            if (success)
            {
                MessageBox.Show("Партия запущена в производство!");
                this.Close();
            }
            else MessageBox.Show("Ошибка при создании!");
        }
    }
}