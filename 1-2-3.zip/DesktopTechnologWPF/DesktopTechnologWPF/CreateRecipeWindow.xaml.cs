﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class CreateRecipeWindow : Window
    {
        public CreateRecipeWindow() { InitializeComponent(); }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var newItem = new Recipe { ProductName = TxtProductName.Text, Version = TxtVersion.Text };
            bool success = await ApiService.CreateRecipe(newItem);
            if (success)
            {
                MessageBox.Show("Успешно добавлено!");
                this.Close();
            }
            else MessageBox.Show("Ошибка при создании!");
        }
    }
}