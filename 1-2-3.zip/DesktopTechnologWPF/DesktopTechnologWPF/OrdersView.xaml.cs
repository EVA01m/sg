﻿using System.Windows;
using System.Windows.Controls;

namespace DesktopTechnologWPF
{
    public partial class OrdersView : UserControl
    {
        public OrdersView()
        {
            InitializeComponent();
            Loaded += OrdersView_Loaded;
        }

        private async void OrdersView_Loaded(object sender, RoutedEventArgs e)
        {
            GridOrders.ItemsSource = await ApiService.GetOrders();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            var win = new CreateOrderWindow();
            win.ShowDialog();
            OrdersView_Loaded(null, null); // Обновляем таблицу
        }
    }
}