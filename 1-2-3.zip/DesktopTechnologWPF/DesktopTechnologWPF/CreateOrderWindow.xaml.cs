﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class CreateOrderWindow : Window
    {
        public CreateOrderWindow() { InitializeComponent(); }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            // В модели Order дата ставится автоматически в API, тут передаем только номер и продукт
            var newItem = new ProductionOrder { OrderNumber = TxtOrderNumber.Text, ProductName = TxtProductName.Text };
            bool success = await ApiService.CreateOrder(newItem);
            if (success)
            {
                MessageBox.Show("Заказ создан!");
                this.Close();
            }
            else MessageBox.Show("Ошибка при создании!");
        }
    }
}