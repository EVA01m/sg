﻿using System.Linq;
using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class ProductCardWindow : Window
    {
        private Product _product;

        public ProductCardWindow(Product product)
        {
            InitializeComponent();
            _product = product;
            LoadData();
        }

        private async void LoadData()
        {
            TxtTitle.Text = $"Продукт: {_product.Name}";
            TxtInfoCode.Text = "Код продукта: " + _product.Code;
            TxtInfoType.Text = "Тип (ID): " + _product.Type;
            TxtInfoForm.Text = "Форма выпуска: " + _product.Form;
            TxtInfoStatus.Text = "Статус: " + _product.Status;

            // Асинхронно подтягиваем связанные рецептуры и техкарты по имени
            var allRecipes = await ApiService.GetRecipes();
            GridRecipes.ItemsSource = allRecipes.Where(r => r.ProductName == _product.Name).ToList();

            var allTechMaps = await ApiService.GetTechMaps();
            GridTechMaps.ItemsSource = allTechMaps.Where(t => t.ProductName == _product.Name).ToList();

            var allBatches = await ApiService.GetBatches();
            GridBatches.ItemsSource = allBatches.Where(b => b.ProductName == _product.Name).ToList();
        }
    }
}