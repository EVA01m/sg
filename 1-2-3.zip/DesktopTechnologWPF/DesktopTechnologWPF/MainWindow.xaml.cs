﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // При запуске открываем Главную страницу
            MainContent.Content = new DashboardView();
        }

        // --- ОБРАБОТЧИКИ КНОПОК МЕНЮ ---

        private void BtnDashboard_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new DashboardView();
        }

        private void BtnProducts_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ProductsView();
        }

        private void BtnRecipes_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new RecipesView();
        }

        private void BtnTechMaps_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new TechMapsView();
        }

        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new OrdersView();
        }

        private void BtnBatches_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new BatchesView();
        }

        private void BtnExtruder_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ExtruderView();
        }

        private void BtnEvents_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new EventsView();
        }

        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            MainContent.Content = new ReportsView();
        }

        // --- ОБРАБОТЧИКИ МЕНЮ ПРОФИЛЯ (Справа вверху) ---

        private void MenuProfile_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("ФИО: Иванов И.И.\nРоль: Технолог\nПодразделение: Технологический отдел", "Профиль");
        }

        private void MenuChangePass_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь будет форма смены пароля.", "Безопасность");
        }

        private void MenuExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}