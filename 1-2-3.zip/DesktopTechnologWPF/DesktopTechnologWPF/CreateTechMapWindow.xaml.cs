﻿using System.Windows;

namespace DesktopTechnologWPF
{
    public partial class CreateTechMapWindow : Window
    {
        public CreateTechMapWindow() { InitializeComponent(); }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            var newItem = new TechMap { ProductName = TxtProductName.Text, Version = TxtVersion.Text };
            bool success = await ApiService.CreateTechMap(newItem);
            if (success)
            {
                MessageBox.Show("Техкарта создана!");
                this.Close();
            }
            else MessageBox.Show("Ошибка при создании!");
        }
    }
}