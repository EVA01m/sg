﻿using System.Windows.Controls;
namespace DesktopTechnologWPF { public partial class ExtruderView : UserControl { public ExtruderView() { InitializeComponent(); } } }