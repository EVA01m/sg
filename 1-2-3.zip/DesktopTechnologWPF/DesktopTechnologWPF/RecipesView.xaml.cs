﻿using System.Windows;
using System.Windows.Controls;

namespace DesktopTechnologWPF
{
    public partial class RecipesView : UserControl
    {
        public RecipesView()
        {
            InitializeComponent();
            Loaded += RecipesView_Loaded;
        }

        private async void RecipesView_Loaded(object sender, RoutedEventArgs e)
        {
            GridRecipes.ItemsSource = await ApiService.GetRecipes();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            var win = new CreateRecipeWindow();
            win.ShowDialog(); // Ждем, пока окно закроется
            RecipesView_Loaded(null, null); // Обновляем таблицу
        }
    }
}