﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace DesktopTechnologWPF
{
    public static class ApiService
    {
        private static readonly string BaseUrl = "http://localhost:5274/api";
        private static string _token = "";

        public static async Task<bool> Login(string username, string password)
        {
            using (HttpClient client = new HttpClient())
            {
                var body = new { Username = username, Password = password };
                var serializer = new JavaScriptSerializer();
                var jsonBody = serializer.Serialize(body);
                var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync($"{BaseUrl}/Auth/login", content);
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var result = serializer.Deserialize<LoginResponse>(jsonResponse);

                    if (result != null && result.Success)
                    {
                        _token = result.Data;
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Ошибка подключения к API при логине: " + ex.Message);
                }
                return false;
            }
        }

        // --- ПРОДУКЦИЯ ---
        public static async Task<List<Product>> GetProducts()
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
                try
                {
                    var response = await client.GetAsync($"{BaseUrl}/Products");
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var serializer = new JavaScriptSerializer();
                    var result = serializer.Deserialize<ProductsResponse>(jsonResponse);
                    return (result != null && result.Success) ? result.Data : new List<Product>();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Ошибка сети: " + ex.Message);
                    return new List<Product>();
                }
            }
        }
        public static async Task<bool> ArchiveProduct(int id)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
                var response = await client.PutAsync($"{BaseUrl}/Products/{id}/archive", null);
                return response.IsSuccessStatusCode;
            }
        }

        public static async Task<bool> CreateProduct(Product p)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
                var serializer = new JavaScriptSerializer();
                var jsonBody = serializer.Serialize(p);
                var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
                try
                {
                    var response = await client.PostAsync($"{BaseUrl}/Products", content);
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    if (!response.IsSuccessStatusCode) return false;
                    var result = serializer.Deserialize<ApiResponseSimple>(jsonResponse);
                    return result != null && result.Success;
                }
                catch { return false; }
            }
        }

        // --- УНИВЕРСАЛЬНЫЕ МЕТОДЫ ДЛЯ НОВЫХ РАЗДЕЛОВ ---

        private static async Task<List<T>> GetListAsync<T>(string endpoint) where T : class
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
                try
                {
                    var response = await client.GetStringAsync($"{BaseUrl}/{endpoint}");
                    var serializer = new JavaScriptSerializer();
                    var result = serializer.Deserialize<GenericResponse<List<T>>>(response);
                    return (result != null && result.Success) ? result.Data : new List<T>();
                }
                catch { return new List<T>(); }
            }
        }

        public static async Task<List<Recipe>> GetRecipes() => await GetListAsync<Recipe>("Data/recipes");
        public static async Task<List<TechMap>> GetTechMaps() => await GetListAsync<TechMap>("Data/techmaps");
        public static async Task<List<ProductionOrder>> GetOrders() => await GetListAsync<ProductionOrder>("Data/orders");
        public static async Task<List<ProductionBatch>> GetBatches() => await GetListAsync<ProductionBatch>("Data/batches");
        public static async Task<List<EventItem>> GetEvents() => await GetListAsync<EventItem>("Data/events");

        public static async Task<bool> CreateRecipe(Recipe item) => await PostData("Data/recipes", item);
        public static async Task<bool> CreateTechMap(TechMap item) => await PostData("Data/techmaps", item);
        public static async Task<bool> CreateOrder(ProductionOrder item) => await PostData("Data/orders", item);
        public static async Task<bool> CreateBatch(ProductionBatch item) => await PostData("Data/batches", item);

        private static async Task<bool> PostData<T>(string endpoint, T item)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _token);
                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(item);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync($"{BaseUrl}/{endpoint}", content);
                    return response.IsSuccessStatusCode;
                }
                catch { return false; }
            }
        }
    }

    // --- ВСПОМОГАТЕЛЬНЫЕ КЛАССЫ ДЛЯ ПАРСИНГА ОТВЕТОВ ---
    public class LoginResponse
    {
        public bool Success { get; set; }
        public string Data { get; set; }
    }

    public class ProductsResponse
    {
        public bool Success { get; set; }
        public List<Product> Data { get; set; }
        public string Message { get; set; }
    }

    public class ApiResponseSimple
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }

    public class GenericResponse<T>
    {
        public bool Success { get; set; }
        public T Data { get; set; }
        public string Message { get; set; }
    }
}