﻿using System.Windows.Controls;
namespace DesktopTechnologWPF
{
    public partial class DashboardView : UserControl
    {
        public DashboardView() { InitializeComponent(); Loaded += async (s, e) => { GridEvents.ItemsSource = await ApiService.GetEvents(); }; }
    }
}