﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace DesktopTechnologWPF
{
    public partial class ProductsView : UserControl
    {
        private List<Product> _allProducts = new List<Product>();

        public ProductsView()
        {
            InitializeComponent();
            Loaded += ProductsView_Loaded;
        }

        private async void ProductsView_Loaded(object sender, RoutedEventArgs e)
        {
            _allProducts = await ApiService.GetProducts();
            ApplyFilters();
        }

        // Обработчики событий поиска и фильтров
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();
        private void Filter_Changed(object sender, SelectionChangedEventArgs e) => ApplyFilters();

        private void ApplyFilters()
        {
            // ГЛАВНАЯ ЗАЩИТА: Если интерфейс еще не прогрузился или данные не пришли - стоп.
            if (GridProducts == null || TxtSearch == null || CmbFilterType == null || CmbFilterStatus == null) return;
            if (_allProducts == null) return;

            var filtered = _allProducts.AsEnumerable();

            // 1. Фильтр по поиску
            if (!string.IsNullOrWhiteSpace(TxtSearch.Text))
            {
                string search = TxtSearch.Text.ToLower();
                filtered = filtered.Where(p => p.Name.ToLower().Contains(search) || p.Code.ToLower().Contains(search));
            }

            // 2. Фильтр по типу (ID)
            if (CmbFilterType.SelectedIndex == 1) filtered = filtered.Where(p => p.Type == "1"); // Гербицид
            if (CmbFilterType.SelectedIndex == 2) filtered = filtered.Where(p => p.Type == "2"); // Инсектицид

            // 3. Фильтр по статусу
            string status = (CmbFilterStatus.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (!string.IsNullOrEmpty(status) && status != "Все")
            {
                filtered = filtered.Where(p => p.Status == status);
            }

            GridProducts.ItemsSource = filtered.ToList();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            new CreateProductWindow().ShowDialog();
            ProductsView_Loaded(null, null);
        }

        private async void BtnArchive_Click(object sender, RoutedEventArgs e)
        {
            if (GridProducts.SelectedItem is Product selectedProduct)
            {
                var result = MessageBox.Show($"Отправить '{selectedProduct.Name}' в архив?", "Подтверждение", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    if (await ApiService.ArchiveProduct(selectedProduct.Id))
                    {
                        ProductsView_Loaded(null, null); // Обновляем таблицу
                    }
                }
            }
            else MessageBox.Show("Выберите продукт!");
        }

        private void GridProducts_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (GridProducts.SelectedItem is Product selectedProduct)
            {
                new ProductCardWindow(selectedProduct).ShowDialog();
            }
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (GridProducts.ItemsSource == null) return;
            SaveFileDialog sfd = new SaveFileDialog { Filter = "CSV файл (*.csv)|*.csv", FileName = "Продукция.csv" };
            if (sfd.ShowDialog() == true)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Код;Наименование;Тип;Форма;Статус;Рецептура;Техкарта");
                foreach (Product p in GridProducts.ItemsSource)
                    sb.AppendLine($"{p.Code};{p.Name};{p.Type};{p.Form};{p.Status};{p.ActiveRecipe};{p.ActiveTechMap}");
                File.WriteAllText(sfd.FileName, sb.ToString(), new UTF8Encoding(true));
                MessageBox.Show("Экспортировано!");
            }
        }
    }
}