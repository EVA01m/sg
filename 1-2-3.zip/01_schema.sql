﻿/* =========================================================
   01_schema.sql
   Полная схема БД для ИС «Производство»
   СУБД: Microsoft SQL Server 2016+
   ========================================================= */

-- 0. Пересоздание базы (если нужно)
IF DB_ID(N'ProductionDB') IS NOT NULL
BEGIN
    ALTER DATABASE ProductionDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ProductionDB;
END
GO
CREATE DATABASE ProductionDB;
GO
USE ProductionDB;
GO

/* =========================================================
   0.1. Удаление объектов (на случай повторного запуска)
   ========================================================= */
IF OBJECT_ID(N'v_raw_traceability', N'V')  IS NOT NULL DROP VIEW v_raw_traceability;
IF OBJECT_ID(N'v_active_recipes', N'V')    IS NOT NULL DROP VIEW v_active_recipes;
IF OBJECT_ID(N'v_batch_full', N'V')        IS NOT NULL DROP VIEW v_batch_full;

DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS audit_events;
DROP TABLE IF EXISTS deviations;
DROP TABLE IF EXISTS lab_tests;
DROP TABLE IF EXISTS equipment_telemetry;
DROP TABLE IF EXISTS step_execution_params;
DROP TABLE IF EXISTS step_executions;
DROP TABLE IF EXISTS batch_raw_usage;
DROP TABLE IF EXISTS production_batches;
DROP TABLE IF EXISTS production_orders;
DROP TABLE IF EXISTS step_parameters;
DROP TABLE IF EXISTS tech_steps;
DROP TABLE IF EXISTS tech_cards;
DROP TABLE IF EXISTS recipe_components;
DROP TABLE IF EXISTS recipes;
DROP TABLE IF EXISTS raw_batches;
DROP TABLE IF EXISTS equipment;
DROP TABLE IF EXISTS raw_materials;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS product_types;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS roles;
GO

/* =========================================================
   1. СПРАВОЧНИКИ
   ========================================================= */

CREATE TABLE roles (
    id          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_roles PRIMARY KEY,
    name        NVARCHAR(100) NOT NULL CONSTRAINT uq_roles_name UNIQUE,
    description NVARCHAR(400) NULL
);
GO

CREATE TABLE departments (
    id      BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_departments PRIMARY KEY,
    name    NVARCHAR(200) NOT NULL CONSTRAINT uq_departments_name UNIQUE,
    purpose NVARCHAR(400) NULL
);
GO

CREATE TABLE users (
    id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_users PRIMARY KEY,
    full_name     NVARCHAR(200) NOT NULL,
    login         NVARCHAR(100) NOT NULL CONSTRAINT uq_users_login UNIQUE,
    role_id       BIGINT NOT NULL,
    department_id BIGINT NOT NULL,
    is_active     BIT NOT NULL CONSTRAINT df_users_active DEFAULT 1,
    CONSTRAINT fk_users_role FOREIGN KEY (role_id)       REFERENCES roles(id),
    CONSTRAINT fk_users_dept FOREIGN KEY (department_id) REFERENCES departments(id)
);
GO

CREATE TABLE product_types (
    id   BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_product_types PRIMARY KEY,
    name NVARCHAR(100) NOT NULL CONSTRAINT uq_product_types_name UNIQUE
);
GO

CREATE TABLE products (
    id               BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_products PRIMARY KEY,
    name             NVARCHAR(200) NOT NULL,
    product_type_id  BIGINT NOT NULL,
    form_of_release  NVARCHAR(200) NULL,   -- форма выпуска: упаковка, стакан, кг и т.п.
    status           NVARCHAR(50) NOT NULL CONSTRAINT df_products_status DEFAULT N'active',
    CONSTRAINT fk_products_type FOREIGN KEY (product_type_id) REFERENCES product_types(id),
    CONSTRAINT ck_products_status CHECK (status IN (N'active', N'archived', N'blocked'))
);
GO

CREATE TABLE raw_materials (
    id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_raw_materials PRIMARY KEY,
    name          NVARCHAR(200) NOT NULL,
    unit          NVARCHAR(20)  NOT NULL,
    storage_terms NVARCHAR(400) NULL,
    is_active     BIT NOT NULL CONSTRAINT df_raw_materials_active DEFAULT 1
);
GO

CREATE TABLE equipment (
    id         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_equipment PRIMARY KEY,
    name       NVARCHAR(200) NOT NULL,
    code       NVARCHAR(50)  NOT NULL CONSTRAINT uq_equipment_code UNIQUE,
    status     NVARCHAR(50)  NOT NULL CONSTRAINT df_equipment_status DEFAULT N'available',
    CONSTRAINT ck_equipment_status CHECK (status IN (N'available', N'in_use', N'maintenance', N'broken'))
);
GO

/* =========================================================
   2. НОРМАТИВНЫЕ ДАННЫЕ
   ========================================================= */

CREATE TABLE recipes (
    id          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_recipes PRIMARY KEY,
    product_id  BIGINT NOT NULL,
    version_no  INT    NOT NULL,
    status      NVARCHAR(20) NOT NULL CONSTRAINT df_recipes_status DEFAULT N'draft',
    is_active   BIT NOT NULL CONSTRAINT df_recipes_active DEFAULT 0,
    approved_at DATETIME2 NULL,
    approved_by BIGINT NULL,
    created_at  DATETIME2 NOT NULL CONSTRAINT df_recipes_created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT fk_recipes_product  FOREIGN KEY (product_id)  REFERENCES products(id),
    CONSTRAINT fk_recipes_approved FOREIGN KEY (approved_by) REFERENCES users(id),
    CONSTRAINT uq_recipes_product_version UNIQUE (product_id, version_no),
    CONSTRAINT ck_recipes_status CHECK (status IN (N'draft', N'approved', N'archived')),
    CONSTRAINT ck_recipes_active_approved CHECK (is_active = 0 OR status = N'approved')
);
GO

CREATE TABLE recipe_components (
    id              BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_recipe_components PRIMARY KEY,
    recipe_id       BIGINT NOT NULL,
    raw_material_id BIGINT NOT NULL,
    share_percent   DECIMAL(6,3) NOT NULL,
    CONSTRAINT fk_rc_recipe FOREIGN KEY (recipe_id)       REFERENCES recipes(id) ON DELETE CASCADE,
    CONSTRAINT fk_rc_raw    FOREIGN KEY (raw_material_id) REFERENCES raw_materials(id),
    CONSTRAINT uq_rc UNIQUE (recipe_id, raw_material_id),
    CONSTRAINT ck_rc_share CHECK (share_percent > 0 AND share_percent <= 100)
);
GO

CREATE TABLE tech_cards (
    id          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_tech_cards PRIMARY KEY,
    product_id  BIGINT NOT NULL,
    recipe_id   BIGINT NOT NULL,
    version_no  INT    NOT NULL,
    status      NVARCHAR(20) NOT NULL CONSTRAINT df_tc_status DEFAULT N'draft',
    is_active   BIT NOT NULL CONSTRAINT df_tc_active DEFAULT 0,
    approved_at DATETIME2 NULL,
    approved_by BIGINT NULL,
    CONSTRAINT fk_tc_product  FOREIGN KEY (product_id)  REFERENCES products(id),
    CONSTRAINT fk_tc_recipe   FOREIGN KEY (recipe_id)   REFERENCES recipes(id),
    CONSTRAINT fk_tc_approved FOREIGN KEY (approved_by) REFERENCES users(id),
    CONSTRAINT uq_tc_product_version UNIQUE (product_id, version_no),
    CONSTRAINT ck_tc_status CHECK (status IN (N'draft', N'approved', N'archived')),
    CONSTRAINT ck_tc_active_approved CHECK (is_active = 0 OR status = N'approved')
);
GO

CREATE TABLE tech_steps (
    id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_tech_steps PRIMARY KEY,
    tech_card_id BIGINT NOT NULL,
    step_no      INT    NOT NULL,
    name         NVARCHAR(200) NOT NULL,
    description  NVARCHAR(1000) NULL,
    CONSTRAINT fk_ts_card FOREIGN KEY (tech_card_id) REFERENCES tech_cards(id) ON DELETE CASCADE,
    CONSTRAINT uq_ts_step_no UNIQUE (tech_card_id, step_no)
);
GO

CREATE TABLE step_parameters (
    id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_step_parameters PRIMARY KEY,
    tech_step_id BIGINT NOT NULL,
    param_name   NVARCHAR(100) NOT NULL,
    min_value    DECIMAL(18,4) NULL,
    max_value    DECIMAL(18,4) NULL,
    unit         NVARCHAR(20)  NULL,
    CONSTRAINT fk_sp_step FOREIGN KEY (tech_step_id) REFERENCES tech_steps(id) ON DELETE CASCADE,
    CONSTRAINT uq_sp UNIQUE (tech_step_id, param_name),
    CONSTRAINT ck_sp_range CHECK (min_value IS NULL OR max_value IS NULL OR min_value <= max_value)
);
GO

/* =========================================================
   3. ОПЕРАЦИОННЫЕ ДАННЫЕ
   ========================================================= */

CREATE TABLE raw_batches (
    id              BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_raw_batches PRIMARY KEY,
    raw_material_id BIGINT NOT NULL,
    batch_number    NVARCHAR(100) NOT NULL,
    received_at     DATETIME2 NOT NULL CONSTRAINT df_rb_received DEFAULT SYSUTCDATETIME(),
    expiry_at       DATETIME2 NULL,
    status          NVARCHAR(50) NOT NULL CONSTRAINT df_rb_status DEFAULT N'available',
    CONSTRAINT fk_rb_raw FOREIGN KEY (raw_material_id) REFERENCES raw_materials(id),
    CONSTRAINT uq_rb UNIQUE (raw_material_id, batch_number),
    CONSTRAINT ck_rb_status CHECK (status IN (N'available', N'used', N'blocked', N'expired'))
);
GO

CREATE TABLE production_orders (
    id         BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_production_orders PRIMARY KEY,
    product_id BIGINT NOT NULL,
    plan_qty   DECIMAL(18,3) NOT NULL,
    status     NVARCHAR(50) NOT NULL CONSTRAINT df_po_status DEFAULT N'draft',
    created_at DATETIME2 NOT NULL CONSTRAINT df_po_created DEFAULT SYSUTCDATETIME(),
    created_by BIGINT NULL,
    CONSTRAINT fk_po_product FOREIGN KEY (product_id) REFERENCES products(id),
    CONSTRAINT fk_po_created FOREIGN KEY (created_by) REFERENCES users(id),
    CONSTRAINT ck_po_status CHECK (status IN (N'draft', N'released', N'in_production', N'closed', N'cancelled')),
    CONSTRAINT ck_po_qty CHECK (plan_qty > 0)
);
GO

CREATE TABLE production_batches (
    id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_production_batches PRIMARY KEY,
    order_id     BIGINT NOT NULL,
    product_id   BIGINT NOT NULL,
    recipe_id    BIGINT NOT NULL,
    tech_card_id BIGINT NOT NULL,
    batch_number NVARCHAR(100) NOT NULL CONSTRAINT uq_pb_number UNIQUE,
    status       NVARCHAR(50) NOT NULL CONSTRAINT df_pb_status DEFAULT N'created',
    started_at   DATETIME2 NULL,
    completed_at DATETIME2 NULL,
    CONSTRAINT fk_pb_order  FOREIGN KEY (order_id)     REFERENCES production_orders(id),
    CONSTRAINT fk_pb_prod   FOREIGN KEY (product_id)   REFERENCES products(id),
    CONSTRAINT fk_pb_recipe FOREIGN KEY (recipe_id)    REFERENCES recipes(id),
    CONSTRAINT fk_pb_tc     FOREIGN KEY (tech_card_id) REFERENCES tech_cards(id),
    CONSTRAINT ck_pb_status CHECK (status IN (N'created', N'in_progress', N'completed', N'blocked', N'cancelled'))
);
GO

CREATE TABLE batch_raw_usage (
    id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_batch_raw_usage PRIMARY KEY,
    batch_id     BIGINT NOT NULL,
    raw_batch_id BIGINT NOT NULL,
    quantity     DECIMAL(18,3) NOT NULL,
    CONSTRAINT fk_bru_batch FOREIGN KEY (batch_id)     REFERENCES production_batches(id),
    CONSTRAINT fk_bru_raw   FOREIGN KEY (raw_batch_id) REFERENCES raw_batches(id),
    CONSTRAINT uq_bru UNIQUE (batch_id, raw_batch_id),
    CONSTRAINT ck_bru_qty CHECK (quantity > 0)
);
GO

CREATE TABLE step_executions (
    id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_step_executions PRIMARY KEY,
    batch_id      BIGINT NOT NULL,
    tech_step_id  BIGINT NOT NULL,
    status        NVARCHAR(50) NOT NULL CONSTRAINT df_se_status DEFAULT N'pending',
    started_by    BIGINT NULL,
    started_at    DATETIME2 NULL,
    completed_by  BIGINT NULL,
    completed_at  DATETIME2 NULL,
    comment       NVARCHAR(1000) NULL,
    CONSTRAINT fk_se_batch FOREIGN KEY (batch_id)     REFERENCES production_batches(id),
    CONSTRAINT fk_se_step  FOREIGN KEY (tech_step_id) REFERENCES tech_steps(id),
    CONSTRAINT fk_se_sby   FOREIGN KEY (started_by)   REFERENCES users(id),
    CONSTRAINT fk_se_cby   FOREIGN KEY (completed_by) REFERENCES users(id),
    CONSTRAINT ck_se_status CHECK (status IN (N'pending', N'in_progress', N'completed', N'deviation', N'skipped'))
);
GO

CREATE TABLE step_execution_params (
    id                BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_step_execution_params PRIMARY KEY,
    step_execution_id BIGINT NOT NULL,
    param_name        NVARCHAR(100) NOT NULL,
    value             DECIMAL(18,4) NOT NULL,
    unit              NVARCHAR(20)  NULL,
    recorded_at       DATETIME2 NOT NULL CONSTRAINT df_sep_recorded DEFAULT SYSUTCDATETIME(),
    CONSTRAINT fk_sep_se FOREIGN KEY (step_execution_id) REFERENCES step_executions(id) ON DELETE CASCADE,
    CONSTRAINT uq_sep UNIQUE (step_execution_id, param_name)
);
GO

CREATE TABLE equipment_telemetry (
    id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_equipment_telemetry PRIMARY KEY,
    equipment_id BIGINT NOT NULL,
    batch_id     BIGINT NULL,
    param_name   NVARCHAR(100) NOT NULL,
    value        DECIMAL(18,4) NOT NULL,
    unit         NVARCHAR(20)  NULL,
    recorded_at  DATETIME2 NOT NULL CONSTRAINT df_et_recorded DEFAULT SYSUTCDATETIME(),
    CONSTRAINT fk_et_eq    FOREIGN KEY (equipment_id) REFERENCES equipment(id),
    CONSTRAINT fk_et_batch FOREIGN KEY (batch_id)     REFERENCES production_batches(id)
);
GO

CREATE TABLE lab_tests (
    id                  BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_lab_tests PRIMARY KEY,
    raw_batch_id        BIGINT NULL,
    production_batch_id BIGINT NULL,
    test_type           NVARCHAR(100) NOT NULL,
    status              NVARCHAR(50) NOT NULL CONSTRAINT df_lt_status DEFAULT N'planned',
    result              NVARCHAR(50) NULL,
    started_at          DATETIME2 NULL,
    completed_at        DATETIME2 NULL,
    laboratory_user_id  BIGINT NULL,
    CONSTRAINT fk_lt_raw   FOREIGN KEY (raw_batch_id)        REFERENCES raw_batches(id),
    CONSTRAINT fk_lt_batch FOREIGN KEY (production_batch_id) REFERENCES production_batches(id),
    CONSTRAINT fk_lt_user  FOREIGN KEY (laboratory_user_id)  REFERENCES users(id),
    CONSTRAINT ck_lt_status CHECK (status IN (N'planned', N'in_progress', N'passed', N'failed', N'cancelled')),
    CONSTRAINT ck_lt_result CHECK (result IS NULL OR result IN (N'ok', N'not_ok')),
    CONSTRAINT ck_lt_target CHECK (
        (raw_batch_id IS NOT NULL AND production_batch_id IS NULL)
        OR (raw_batch_id IS NULL AND production_batch_id IS NOT NULL)
    )
);
GO

CREATE TABLE deviations (
    id                 BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_deviations PRIMARY KEY,
    batch_id           BIGINT NOT NULL,
    step_execution_id  BIGINT NULL,
    severity           NVARCHAR(20) NOT NULL CONSTRAINT df_dev_sev DEFAULT N'warning',
    description        NVARCHAR(2000) NOT NULL,
    status             NVARCHAR(50) NOT NULL CONSTRAINT df_dev_status DEFAULT N'open',
    created_at         DATETIME2 NOT NULL CONSTRAINT df_dev_created DEFAULT SYSUTCDATETIME(),
    resolved_at        DATETIME2 NULL,
    resolved_by        BIGINT NULL,
    resolution         NVARCHAR(2000) NULL,
    CONSTRAINT fk_dev_batch FOREIGN KEY (batch_id)          REFERENCES production_batches(id),
    CONSTRAINT fk_dev_step  FOREIGN KEY (step_execution_id) REFERENCES step_executions(id),
    CONSTRAINT fk_dev_user  FOREIGN KEY (resolved_by)       REFERENCES users(id),
    CONSTRAINT ck_dev_sev   CHECK (severity IN (N'info', N'warning', N'critical')),
    CONSTRAINT ck_dev_state CHECK (status IN (N'open', N'in_review', N'closed'))
);
GO

CREATE TABLE notifications (
    id                  BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_notifications PRIMARY KEY,
    recipient_user_id   BIGINT NOT NULL,
    related_entity_type NVARCHAR(100) NULL,
    related_entity_id   BIGINT NULL,
    message             NVARCHAR(2000) NOT NULL,
    is_read             BIT NOT NULL CONSTRAINT df_notif_read DEFAULT 0,
    created_at          DATETIME2 NOT NULL CONSTRAINT df_notif_created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT fk_notif_user FOREIGN KEY (recipient_user_id) REFERENCES users(id)
);
GO

/* =========================================================
   4. АУДИТ
   ========================================================= */

CREATE TABLE audit_events (
    id          BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_audit_events PRIMARY KEY,
    entity_type NVARCHAR(100) NOT NULL,
    entity_id   BIGINT NOT NULL,
    event_type  NVARCHAR(100) NOT NULL,
    old_status  NVARCHAR(50)  NULL,
    new_status  NVARCHAR(50)  NULL,
    user_id     BIGINT NULL,
    event_time  DATETIME2 NOT NULL CONSTRAINT df_ae_time DEFAULT SYSUTCDATETIME(),
    details     NVARCHAR(MAX) NULL,
    CONSTRAINT fk_ae_user FOREIGN KEY (user_id) REFERENCES users(id)
);
GO

/* =========================================================
   5. ИНДЕКСЫ (в т.ч. ОБЯЗАТЕЛЬНЫЕ УНИКАЛЬНЫЕ ФИЛЬТРУЕМЫЕ)
   ========================================================= */

-- Ограничение 1: одна действующая утверждённая рецептура на продукт
CREATE UNIQUE INDEX ux_recipes_one_active_approved
ON recipes(product_id)
WHERE status = N'approved' AND is_active = 1;
GO

-- Ограничение 2: одна действующая утверждённая техкарта на продукт
CREATE UNIQUE INDEX ux_tech_cards_one_active_approved
ON tech_cards(product_id)
WHERE status = N'approved' AND is_active = 1;
GO

-- Вспомогательные индексы
CREATE INDEX ix_rb_material ON raw_batches(raw_material_id);
CREATE INDEX ix_pb_order    ON production_batches(order_id);
CREATE INDEX ix_se_batch    ON step_executions(batch_id);
CREATE INDEX ix_se_step     ON step_executions(tech_step_id);
CREATE INDEX ix_ae_entity   ON audit_events(entity_type, entity_id);
CREATE INDEX ix_lt_batch    ON lab_tests(production_batch_id);
CREATE INDEX ix_lt_raw      ON lab_tests(raw_batch_id);
GO

/* =========================================================
   6. ТРИГГЕРЫ
   ========================================================= */

/* 6.1. Нельзя утвердить рецептуру, если сумма долей ≠ 100% */
CREATE OR ALTER TRIGGER trg_recipes_check_sum
ON recipes
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @to_check TABLE (recipe_id BIGINT PRIMARY KEY);

    INSERT INTO @to_check (recipe_id)
    SELECT i.id
    FROM inserted i
    WHERE i.status = N'approved'
      AND NOT EXISTS (
          SELECT 1 FROM deleted d
          WHERE d.id = i.id AND d.status = N'approved'
      );

    IF NOT EXISTS (SELECT 1 FROM @to_check) RETURN;

    DECLARE @bad_id BIGINT, @bad_sum DECIMAL(18,3);

    SELECT TOP 1 @bad_id = r.id,
                 @bad_sum = ISNULL(SUM(rc.share_percent), 0)
    FROM recipes r
    JOIN @to_check t ON t.recipe_id = r.id
    LEFT JOIN recipe_components rc ON rc.recipe_id = r.id
    GROUP BY r.id
    HAVING ABS(ISNULL(SUM(rc.share_percent), 0) - 100) > 0.001;

    IF @bad_id IS NOT NULL
    BEGIN
        DECLARE @msg NVARCHAR(400) = CONCAT(
            N'Нельзя утвердить рецептуру ', @bad_id,
            N': сумма долей = ', @bad_sum, N'%, требуется 100%');
        THROW 50001, @msg, 1;
    END
END;
GO

/* 6.2. Нельзя менять состав утверждённой рецептуры так, чтобы сумма ≠ 100% */
CREATE OR ALTER TRIGGER trg_recipe_components_check_sum
ON recipe_components
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @affected TABLE (recipe_id BIGINT PRIMARY KEY);

    INSERT INTO @affected (recipe_id)
    SELECT recipe_id FROM inserted
    UNION
    SELECT recipe_id FROM deleted;

    DECLARE @bad_id BIGINT, @bad_sum DECIMAL(18,3);

    SELECT TOP 1 @bad_id = r.id,
                 @bad_sum = ISNULL(SUM(rc.share_percent), 0)
    FROM @affected a
    JOIN recipes r ON r.id = a.recipe_id
    LEFT JOIN recipe_components rc ON rc.recipe_id = r.id
    WHERE r.status = N'approved'
    GROUP BY r.id
    HAVING ABS(ISNULL(SUM(rc.share_percent), 0) - 100) > 0.001;

    IF @bad_id IS NOT NULL
    BEGIN
        DECLARE @msg NVARCHAR(400) = CONCAT(
            N'Нельзя менять состав утверждённой рецептуры ', @bad_id,
            N': сумма долей = ', @bad_sum, N'%');
        THROW 50002, @msg, 1;
    END
END;
GO

/* 6.3. Аудит статусов ключевых сущностей (универсальный) */

CREATE OR ALTER TRIGGER trg_recipes_audit
ON recipes AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'recipe', i.id, N'insert', NULL, i.status, SYSUTCDATETIME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'recipe', i.id, N'update', d.status, i.status, SYSUTCDATETIME()
    FROM inserted i JOIN deleted d ON d.id = i.id
    WHERE ISNULL(i.status, N'') <> ISNULL(d.status, N'');

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'recipe', d.id, N'delete', d.status, NULL, SYSUTCDATETIME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END;
GO

CREATE OR ALTER TRIGGER trg_tech_cards_audit
ON tech_cards AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'tech_card', i.id, N'insert', NULL, i.status, SYSUTCDATETIME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'tech_card', i.id, N'update', d.status, i.status, SYSUTCDATETIME()
    FROM inserted i JOIN deleted d ON d.id = i.id
    WHERE ISNULL(i.status, N'') <> ISNULL(d.status, N'');

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'tech_card', d.id, N'delete', d.status, NULL, SYSUTCDATETIME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END;
GO

CREATE OR ALTER TRIGGER trg_production_batches_audit
ON production_batches AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'production_batch', i.id, N'insert', NULL, i.status, SYSUTCDATETIME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'production_batch', i.id, N'update', d.status, i.status, SYSUTCDATETIME()
    FROM inserted i JOIN deleted d ON d.id = i.id
    WHERE ISNULL(i.status, N'') <> ISNULL(d.status, N'');

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'production_batch', d.id, N'delete', d.status, NULL, SYSUTCDATETIME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END;
GO

CREATE OR ALTER TRIGGER trg_step_executions_audit
ON step_executions AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'step_execution', i.id, N'insert', NULL, i.status, SYSUTCDATETIME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'step_execution', i.id, N'update', d.status, i.status, SYSUTCDATETIME()
    FROM inserted i JOIN deleted d ON d.id = i.id
    WHERE ISNULL(i.status, N'') <> ISNULL(d.status, N'');

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'step_execution', d.id, N'delete', d.status, NULL, SYSUTCDATETIME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END;
GO

CREATE OR ALTER TRIGGER trg_lab_tests_audit
ON lab_tests AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'lab_test', i.id, N'insert', NULL, i.status, SYSUTCDATETIME()
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM deleted d WHERE d.id = i.id);

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'lab_test', i.id, N'update', d.status, i.status, SYSUTCDATETIME()
    FROM inserted i JOIN deleted d ON d.id = i.id
    WHERE ISNULL(i.status, N'') <> ISNULL(d.status, N'');

    INSERT INTO audit_events(entity_type, entity_id, event_type, old_status, new_status, event_time)
    SELECT N'lab_test', d.id, N'delete', d.status, NULL, SYSUTCDATETIME()
    FROM deleted d
    WHERE NOT EXISTS (SELECT 1 FROM inserted i WHERE i.id = d.id);
END;
GO

/* =========================================================
   7. ПРЕДСТАВЛЕНИЯ
   ========================================================= */

CREATE OR ALTER VIEW v_active_recipes AS
SELECT r.id, r.product_id, p.name AS product_name,
       r.version_no, r.status, r.is_active, r.approved_at
FROM recipes r
JOIN products p ON p.id = r.product_id
WHERE r.status = N'approved' AND r.is_active = 1;
GO

CREATE OR ALTER VIEW v_batch_full AS
SELECT pb.id, pb.batch_number, pb.status,
       p.name AS product_name,
       r.version_no AS recipe_version,
       tc.version_no AS tech_card_version,
       pb.started_at, pb.completed_at
FROM production_batches pb
JOIN products      p  ON p.id  = pb.product_id
JOIN recipes       r  ON r.id  = pb.recipe_id
JOIN tech_cards    tc ON tc.id = pb.tech_card_id;
GO

CREATE OR ALTER VIEW v_raw_traceability AS
SELECT pb.batch_number AS product_batch,
       p.name         AS product_name,
       rb.batch_number AS raw_batch,
       rm.name        AS raw_material,
       bru.quantity,
       rm.unit
FROM batch_raw_usage bru
JOIN production_batches pb ON pb.id = bru.batch_id
JOIN products           p  ON p.id  = pb.product_id
JOIN raw_batches        rb ON rb.id = bru.raw_batch_id
JOIN raw_materials      rm ON rm.id = rb.raw_material_id;
GO